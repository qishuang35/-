package chatRoom;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * 聊天室服务器
 * <p>
 * 该类实现了一个简单的聊天室服务器，能够接收来自多个客户端的连接
 * 并实现消息的广播功能。服务器启动后，等待客户端接入，接收到消息
 * 后将其广播给所有连接的客户端。
 *
 * @author 欺霜
 */
public class Server {
    private ServerSocket s;
    private List<PrintWriter> allOut = new ArrayList<>();

    /**
     * 构造函数，启动服务器并初始化服务器套接字。
     */
    public Server() {
        System.out.println("正在启动服务器");
        try {
            s = new ServerSocket(8088);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println("服务器启动成功");
        System.out.println("--------------------------------------------------------------------------------------");
    }

    /**
     * 启动服务器，等待客户端接入并为每个连接的客户端创建处理线程。
     */
    public void start() {
        Socket socket = null;
        System.out.println("正在等待客户端接入");
        while (true) {
            try {
                socket = s.accept();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            ClientHandler c = new ClientHandler(socket);
            Thread t = new Thread(c);
            t.start();
        }
    }

    /**
     * 主方法，启动服务器。
     *
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        Server server = new Server();
        server.start();
    }

    /**
     * 客户端处理器类，实现Runnable接口，用于处理每个客户端的消息接收和发送。
     */
    private class ClientHandler implements Runnable {
        private Socket socket;

        /**
         * 构造函数，初始化客户端套接字。
         *
         * @param socket 客户端套接字
         */
        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        /**
         * 运行方法，接收客户端发送的消息并进行广播。
         */
        @Override
        public void run() {
            PrintWriter pw = null;
            try {
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);
                BufferedReader br = new BufferedReader(isr);

                OutputStream os = socket.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(os, StandardCharsets.UTF_8);
                BufferedWriter bw = new BufferedWriter(osw);
                pw = new PrintWriter(bw, true);
                synchronized (allOut) {
                    allOut.add(pw);
                }
                String message;
                while ((message = br.readLine()) != null) {
                    sendMessage(message);
                    System.out.println();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            } finally {
                synchronized (allOut) {
                    allOut.remove(pw);
                }
                System.out.println();
                try {
                    socket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        /**
         * 广播给定的消息
         *
         * @param message
         */
        private void sendMessage(String message) {
            System.out.println(message);
            synchronized (allOut) {
                for (PrintWriter e : allOut) {
                    e.println(message);
                }
            }

        }
    }
}
