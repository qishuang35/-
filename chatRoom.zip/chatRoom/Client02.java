package chatRoom;


import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * 聊天室客户端
 *
 * 该类实现了聊天室客户端，能够连接到聊天室服务器，与其他客户端进行交流，
 * 并将交流的信息记录到文档中。客户端启动后要求用户输入名称，然后进入消息
 * 发送与接收状态。
 *
 * @author 欺霜
 */
public class Client02 {
    private Socket socket;
    private String name;

    Scanner sc = new Scanner(System.in);

    /**
     * 构造函数，初始化客户端并连接到服务器。
     *
     * @param name 用户名称
     */
    public Client02(String name) {
        this.name = name;
        try {
            System.out.println("正在启动客户端");
            socket = new Socket("localhost", 8088);
            System.out.println("客户端启动成功");
            System.out.println("**------------------**-------------------**----------------------**");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 启动客户端，创建接收消息的线程，并处理用户输入。
     */
    private void start() {
        GetMessage g = new GetMessage();
        Thread t = new Thread(g);
        t.setDaemon(true);
        t.start();
        try {
            OutputStream os = socket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, StandardCharsets.UTF_8);
            BufferedWriter bw = new BufferedWriter(osw);
            PrintWriter pw = new PrintWriter(bw, true);
            PrintWriter pw1 = new PrintWriter(
                    new BufferedWriter(
                            new OutputStreamWriter(
                                    new FileOutputStream("note.txt", true), StandardCharsets.UTF_8)),true);

            System.out.println("请输入：");
            System.out.println("exit结束");
            String message = sc.nextLine();
            while (!message.equalsIgnoreCase("exit")) {
                pw.println(name + ":"+"\t"+"    "+message);
                pw1.println(name + ":");
                pw1.println("    "+message);
                message = sc.nextLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                socket.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 主程序，启动客户端。
     *
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入你的名字：");
        String name = sc.nextLine();
        Client02 c = new Client02(name);
        c.start();

    }

    /**
     * 新建一个线程，持续接收服务端的消息并输出到控制台。
     */

    private class GetMessage implements Runnable {
        @Override
        public void run() {
            try {
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);
                BufferedReader br = new BufferedReader(isr);

                String message;
                while ((message = br.readLine()) != null) {
                    System.out.println(message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}
